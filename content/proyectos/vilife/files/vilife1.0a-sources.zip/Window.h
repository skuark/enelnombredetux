#ifndef WINDOW_H
#define WINDOW_H

#include <QWidget>
#include <QLabel>
using namespace std;

class QSlider;
class GLWidget;

class Window : public QWidget
{
	Q_OBJECT
	
	GLWidget *glWidget;
	QSlider *zoomSlider, *hSlider, *vSlider, *speedSlider;
	QLabel *evoluciones;
	QTimer *timer;
	unsigned int tam;
	char tagEvoluciones[20];
	unsigned int nevoluciones;
	
	QSlider *createHSlider(const char *changedSignal, const char *setterSlot);
	QSlider *createVSlider(const char *changedSignal, const char *setterSlot);
	QSlider *createZoomSlider(const char *changedSignal, const char *setterSlot);
	QSlider *createSpeedSlider(const char *changedSignal, const char *setterSlot);
	
public:
	
	Window(unsigned int tam);
	
public slots:
	void evolucionar();
	void setSpeed(int t);
	
signals:
	void speedChanged(int t);
	
};

#endif
