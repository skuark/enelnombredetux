#include "GLWidget.h"
#include <QtGui>
#include <QtOpenGL>

GLWidget::GLWidget(QWidget *parent, unsigned int tam) :
	QGLWidget(parent)
{
	this->tam = tam;
	nevoluciones = 0;
	zoom=0;
	x = 0;
	y = 0;
	
	matriz = (unsigned char**)malloc(tam*sizeof(unsigned char*));
	if (matriz == NULL) throw ErrNoMem();
	for (unsigned int i=0; i<tam; i++){
		matriz[i] = (unsigned char*)malloc(tam*sizeof(unsigned char));
		if (matriz[i] == NULL) throw ErrNoMem();
	}
	
	matriz2 = (unsigned char**)malloc(tam*sizeof(unsigned char*));
	if (matriz2 == NULL) throw ErrNoMem();
	for (unsigned int i=0; i<tam; i++){
		matriz2[i] = (unsigned char*)malloc(tam*sizeof(unsigned char));
		if (matriz2[i] == NULL) throw ErrNoMem();
	}
	
	/* Debería ser configurable por el usuario ****/
	Estado e1(VIVO, "VIVO", 1.0, 0.0, 0.0);
	Estado e2(MUERTO, "MUERTO", 1.0, 1.0, 1.0);
	estados.insert(pair<unsigned char, Estado>(VIVO, e1));
	estados.insert(pair<unsigned char, Estado>(MUERTO, e2));
	
	TMov mov1 = {-1,-1};
	TMov mov2 = {0, -1};
	TMov mov3 = {1, -1};
	TMov mov4 = {-1, 0};
	TMov mov5 = {1, 0};
	TMov mov6 = {-1, 1};
	TMov mov7 = {0, 1};
	TMov mov8 = {1, 1};
	vecinos.push_back(mov1);
	vecinos.push_back(mov2);
	vecinos.push_back(mov3);
	vecinos.push_back(mov4);
	vecinos.push_back(mov5);
	vecinos.push_back(mov6);
	vecinos.push_back(mov7);
	vecinos.push_back(mov8);
	/**********************************************/
	
	generarMatrizAleatoria();
}

GLWidget::~GLWidget()
{
	
}

QSize GLWidget::minimumSizeHint() const
{
	return QSize(tam, tam);
}

QSize GLWidget::sizeHint() const
{
	return QSize(tam*2, tam*2);
}

void GLWidget::setH(int x)
{
	if (x != this->x){
		this->x = x;
		emit HChanged(x);
		updateGL();
	}
}

void GLWidget::setV(int y)
{
	if (y != this->y){
		this->y = y;
		emit VChanged(y);
		updateGL();
	}
}

void GLWidget::setZoom(int zoom)
{
	if (zoom != this->zoom){
		this->zoom = zoom;
		emit zoomChanged(zoom);
		updateGL();
	}
}

void GLWidget::initializeGL()
{
	glClearColor(0.0, 0.0, 0.0, 1.0);
}

void GLWidget::paintGL()
{
	glClear(GL_COLOR_BUFFER_BIT);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(zoom-x, tam-zoom-x, zoom-y, tam-zoom-y, 1.0, -0.1);
		
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
		for (double i=0; i<tam; i++){
			for (double j=0; j<tam; j++){
				glColor3f(estados[matriz[(int)i][(int)j]].verR(), estados[matriz[(int)i][(int)j]].verG(), estados[matriz[(int)i][(int)j]].verB());
				glLoadIdentity();
				glTranslatef(i, j, 0);
				glBegin(GL_QUADS);
					glVertex2f(0.0, 0.0);
					glVertex2f(1.0, 0.0);
					glVertex2f(1.0, 1.0);
					glVertex2f(0.0, 1.0);
				glEnd();
			}
		}
	glPopMatrix();
}

void GLWidget::resizeGL(int width, int height)
{
	if (width>height){
		glViewport((width/2)-(height/2), 0, height, height);
	}else if (width<height){
		glViewport(0, (height/2)-(width/2), width, width);
	}else{
		glViewport(0, 0, width, height);
	}
}

void GLWidget::generarMatrizAleatoria()
{
	for (unsigned int i=0; i<tam; i++){
		for (unsigned int j=0; j<tam; j++){
			matriz[i][j] = rand()%estados.size();
		}
	}
}

void GLWidget::evolucionar(unsigned int n)
{
	for (unsigned int veces=0; veces<n; veces++){
		// Las relas de evolución también deberían ser configurables
		// Deberia hacer que esto fuera más eficiente
		unsigned int vivos=0;
		for (unsigned int i=0; i<tam; i++){
			for (unsigned int j=0; j<tam; j++){
				for (unsigned int k=0; k<vecinos.size(); k++)
					if (matriz[(i+vecinos[k].movX)%tam][(j+vecinos[k].movY)%tam] == VIVO) vivos++;
				if ((matriz[i][j] == MUERTO) && (vivos == 3)) matriz2[i][j] = VIVO;
				else if ((matriz[i][j] == VIVO) && ((vivos <= 1) || (vivos > 3))) matriz2[i][j] = MUERTO;
				else if ((matriz[i][j] == VIVO) && ((vivos == 2) || (vivos == 3))) matriz2[i][j] = VIVO;
				else matriz2[i][j] = MUERTO;
				vivos = 0;
			}
		}
		unsigned char **aux;
		aux = matriz;
		matriz = matriz2;
		matriz2 = aux;
		nevoluciones++;
	}
	updateGL();
}
