#include "Estado.h"

Estado::Estado()
{
	
}

Estado::Estado(unsigned int estado, const string nombre, float r, float g, float b)
{
	this->estado = estado;
	this->nombre = nombre;
	this->r = r;
	this->g = g;
	this->b = b;
}
