#include <QApplication>
#include "Window.h"

int main(int argc, char *argv[])
{
	unsigned int tam = 100;
	QApplication app(argc, argv);
	for (int i=0; i<argc; i++){
		if (strcmp("-t", argv[i]) == 0) tam = atoi(argv[i+1]);
	}
	Window mainWin(tam);
	mainWin.show();
	return app.exec();
}
