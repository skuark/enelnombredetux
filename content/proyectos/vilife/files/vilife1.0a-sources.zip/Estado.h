#ifndef ESTADO_H_
#define ESTADO_H_

#include <string>
using namespace std;

class Estado {
	
	unsigned int estado;
	string nombre;
	float r, g, b;
	
public:
	
	Estado();
	Estado(unsigned int estado, const string nombre, float r, float g, float b);
	
	unsigned int verEstado(){ return estado; }
	string verNombre(){ return nombre; }
	float verR(){ return r; }
	float verG(){ return g; }
	float verB(){ return b; }
	
};

#endif /*ESTADO_H_*/
