#include <QtGui>
#include "GLWidget.h"
#include "Window.h"

Window::Window(unsigned int tam)
{
	this->tam = tam;
	nevoluciones = 0;
	
	glWidget = new GLWidget(this, tam);
	
	timer = new QTimer(glWidget);
	connect(timer, SIGNAL(timeout()), SLOT(evolucionar()));
	timer->start(0);
	
	hSlider = createHSlider(SIGNAL(HChanged(int)), SLOT(setH(int)));
	vSlider = createVSlider(SIGNAL(VChanged(int)), SLOT(setV(int)));
	zoomSlider = createZoomSlider(SIGNAL(zoomChanged(int)), SLOT(setZoom(int)));
	speedSlider = createSpeedSlider(SIGNAL(speedChanged(int)), SLOT(setSpeed(int)));
	
	sprintf(tagEvoluciones, "Evoluciones: %u", nevoluciones);
	evoluciones = new QLabel(tagEvoluciones);
	
	QGridLayout *mainLayout = new QGridLayout;
	mainLayout->addWidget(glWidget, 0, 0);
	mainLayout->addWidget(hSlider, 1, 0);
	mainLayout->addWidget(vSlider, 0, 1);
	mainLayout->addWidget(zoomSlider, 0, 2);
	mainLayout->addWidget(speedSlider, 0, 3);
	mainLayout->addWidget(evoluciones, 2, 0);
	setLayout(mainLayout);
	
	zoomSlider->setValue(0);
	speedSlider->setValue(1000);
	setWindowTitle("viLife");
}

QSlider *Window::createHSlider(const char *changedSignal, const char *setterSlot)
{
	QSlider *slider = new QSlider(Qt::Horizontal);
	slider->setRange(-(tam/2), tam/2);
	slider->setTickPosition(QSlider::TicksRight);
	connect(slider, SIGNAL(valueChanged(int)), glWidget, setterSlot);
	connect(glWidget, changedSignal, slider, SLOT(setValue(int)));
	return slider;
}

QSlider *Window::createVSlider(const char *changedSignal, const char *setterSlot)
{
	QSlider *slider = new QSlider(Qt::Vertical);
	slider->setRange(-(tam/2), tam/2);
	slider->setTickPosition(QSlider::TicksRight);
	connect(slider, SIGNAL(valueChanged(int)), glWidget, setterSlot);
	connect(glWidget, changedSignal, slider, SLOT(setValue(int)));
	return slider;
}

QSlider *Window::createZoomSlider(const char *changedSignal, const char *setterSlot)
{
	QSlider *slider = new QSlider(Qt::Vertical);
	slider->setRange(0, (tam/2)-1);
	slider->setTickPosition(QSlider::TicksRight);
	connect(slider, SIGNAL(valueChanged(int)), glWidget, setterSlot);
	connect(glWidget, changedSignal, slider, SLOT(setValue(int)));
	return slider;
}

QSlider *Window::createSpeedSlider(const char *changedSignal, const char *setterSlot)
{
	QSlider *slider = new QSlider(Qt::Vertical);
	slider->setRange(0, 1000);
	slider->setTickPosition(QSlider::TicksRight);
	connect(slider, SIGNAL(valueChanged(int)), this, setterSlot);
	connect(this, changedSignal, slider, SLOT(setValue(int)));
	return slider;
}

void Window::evolucionar()
{
	glWidget->evolucionar();
	this->nevoluciones++;
	sprintf(tagEvoluciones, "Evoluciones: %u", nevoluciones);
	evoluciones->setText(tagEvoluciones);
}

void Window::setSpeed(int t)
{
	timer->setInterval(t);
}
