#ifndef GLWIDGET_H
#define GLWIDGET_H

#include <QGLWidget>
#include <map>
#include <vector>
#include "Estado.h"

class ErrNoMem {};

class GLWidget : public QGLWidget
{
	Q_OBJECT
	
public:
	GLWidget(QWidget *parent = 0, unsigned int tam = 100);
	~GLWidget();
	
	QSize minimumSizeHint() const;
	QSize sizeHint() const;
	
public slots:
	void setH(int x);
	void setV(int y);
	void setZoom(int zoom);
	void evolucionar(unsigned int veces = 1);
	
signals:
	void HChanged(int x);
	void VChanged(int y);
	void zoomChanged(int zoom);
	void timeout();
	
protected:
	void initializeGL();
	void paintGL();
	void resizeGL(int width, int height);
	
private:
	unsigned int tam;
	unsigned int nevoluciones;
	enum estado {MUERTO=0, VIVO};
	unsigned char **matriz, **matriz2;
	map<unsigned char, Estado> estados;
	typedef struct {
		int movX;
		int movY;
	} TMov;
	vector<TMov> vecinos;
	int zoom, x, y;
	
	void generarMatrizAleatoria();
	
};

#endif
